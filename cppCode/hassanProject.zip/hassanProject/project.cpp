#include<iostream>
#include<fstream>
#include<cstring>

using namespace std;
void mathQuiz();
void pstQuiz();
void compQuiz();

int main()
{
    cout<<"Welcome to Quiz Management App!"<<endl
    <<"1 for Maths"<<endl<<"2 for Pak studies"<<endl<<"3 for computer science: ";
    int ch;
    cin>>ch;
    if(ch == 1)
        mathQuiz();
    else if(ch == 2)
        pstQuiz();
    else if(ch == 3)
        compQuiz();
    else
        cout<<"Invalid option!";
    return 0;
}
void mathQuiz()
{
    cout<<"MCQs for Maths are: "<<endl;
    int score = 0;
    char *arr = new char[10];
    char *ans = new char[10];
    fstream fileObj("answerMath.txt", ios::in);
    for(int i = 0; i < 10; i++)
        fileObj>>ans[i];
    fileObj.close();
    cout << "Q1. What is the value of Pi?\n";
    cout << "a) 3.14\nb) 4.2\nc) 6.1\n";
    cout << "Your answer: ";
    cin >> arr[0];
    if (arr[0] == ans[0]) 
        score++;
    cout << "Q2. What is the square root of 16?\n";
    cout << "a) 2\nb) 4\nc) 8\n";
    cout << "Your answer: ";
    cin >> arr[1];
    if (arr[1] == ans[1]) 
        score++;
    cout << "Q3. What is the cube of 3?\n";
    cout << "a) 6\nb) 9\nc) 27\n";
    cout << "Your answer: ";
    cin >> arr[2];
    if (arr[2] == ans[2]) 
        score++;
    cout << "Q4. What is the result of 8 divided by 2?\n";
    cout << "a) 4\nb) 6\nc) 8\n";
    cout << "Your answer: ";
    cin >> arr[3];
    if (arr[3] == ans[3]) 
        score++;
    cout << "Q5. What is the product of 5 and 6?\n";
    cout << "a) 10\nb) 25\nc) 30\n";
    cout << "Your answer: ";
    cin >> arr[4];
    if (arr[4] == ans[4]) 
        score++;
    cout << "Q6. What is the result of 12 minus 7?\n";
    cout << "a) 4\nb) 5\nc) 7\n";
    cout << "Your answer: ";
    cin >> arr[5];
    if (arr[5] == ans[5]) 
        score++;
    cout << "Q7. What is the value of 2 raised to the power of 4?\n";
    cout << "a) 2\nb) 4\nc) 16\n";
    cout << "Your answer: ";
    cin >> arr[6];
    if (arr[6] == ans[6])
        score++;
    cout << "Q8. What is the result of 15 multiplied by 3?\n";
    cout << "a) 18\nb) 45\nc) 48\n";
    cout << "Your answer: ";
    cin >> arr[7];
    if (arr[7] == ans[7]) 
        score++;
    cout << "Q9. What is the result of 25 divided by 5?\n";
    cout << "a) 4\nb) 5\nc) 10\n";
    cout << "Your answer: ";
    cin >> arr[8];
    if (arr[8] == ans[8]) 
        score++;
    cout << "Q10. What is the square of 9?\n";
    cout << "a) 3\nb) 6\nc) 81\n";
    cout << "Your answer: ";
    cin >> arr[9];
    if (arr[9] == ans[9])
        score++;
    cout<<"Enter your name without spaces (use - instead): ";
    char *name = new char[30];
    cin>>name;
    fstream fileSave("recordsMaths.txt", ios::app);
    cout << name << " Your score: " << score << "/10\n";
    fileSave << name << " Your score: " << score << "/10\n";
    fileSave.close();
    delete[] arr;
    delete[] ans;
    delete[] name;
}
void pstQuiz()
{
    cout<<"MCQs for Pak study are: "<<endl;
    int score = 0;
    char *arr = new char[10];
    char *ans = new char[10];
    fstream fileObj("answersPST.txt", ios::in);
    for(int i = 0; i < 10; i++)
        fileObj>>ans[i];
    fileObj.close();
    cout << "Q1. What is the capital of Pakistan?\n";
    cout << "a) Lahore\nb) Islamabad\nc) Karachi\n";
    cout << "Your answer: ";
    cin >> arr[0];
    if (arr[0] == ans[0]) 
        score++;
    cout << "Q2. Which river flows through Lahore?\n";
    cout << "a) Jhelum\nb) Ravi\nc) Chenab\n";
    cout << "Your answer: ";
    cin >> arr[1];
    if (arr[1] == ans[1]) 
        score++;
    cout << "Q3. What is the national language of Pakistan?\n";
    cout << "a) Urdu\nb) Punjabi\nc) Sindhi\n";
    cout << "Your answer: ";
    cin >> arr[2];
    if (arr[2] == ans[2]) 
        score++;
    cout << "Q4. Who is the founder of Pakistan?\n";
    cout << "a) Muhammad Ali Jinnah\nb) Allama Iqbal\nc) Liaquat Ali Khan\n";
    cout << "Your answer: ";
    cin >> arr[3];
    if (arr[3] == ans[3]) 
        score++;
    cout << "Q5. Which mountain range is located in Pakistan?\n";
    cout << "a) Himalayas\nb) Andes\nc) Alps\n";
    cout << "Your answer: ";
    cin >> arr[4];
    if (arr[4] == ans[4]) 
        score++;
    cout << "Q6. Which province of Pakistan has the largest population?\n";
    cout << "a) Punjab\nb) Sindh\nc) Balochistan\n";
    cout << "Your answer: ";
    cin >> arr[5];
    if (arr[5] == ans[5]) 
        score++;
    cout << "Q7. Which city is known as the 'City of Gardens' in Pakistan?\n";
    cout << "a) Lahore\nb) Islamabad\nc) Peshawar\n";
    cout << "Your answer: ";
    cin >> arr[6];
    if (arr[6] == ans[6]) 
        score++;
    cout << "Q8. What is the national animal of Pakistan?\n";
    cout << "a) Lion\nb) Markhor\nc) Peacock\n";
    cout << "Your answer: ";
    cin >> arr[7];
    if (arr[7] == ans[7]) 
        score++;
    cout << "Q9. Which Pakistani cricketer has the most centuries in One Day Internationals (ODIs)?\n";
    cout << "a) Imran Khan\nb) Wasim Akram\nc) Inzamam-ul-Haq\n";
    cout << "Your answer: ";
    cin >> arr[8];
    if (arr[8] == ans[8]) 
        score++;
    cout << "Q10. Which famous archaeological site is located in Pakistan?\n";
    cout << "a) Great Wall of China\nb) Angkor Wat\nc) Mohenjo-daro\n";
    cout << "Your answer: ";
    cin >> arr[9];
    if (arr[9] == ans[9])
        score++;
    cout<<"Enter your name without spaces (use - instead): ";
    char *name = new char[30];
    cin>>name;
    fstream fileSave("recordsPST.txt", ios::app);
    cout << name << " Your score: " << score << "/10\n";
    fileSave << name << " Your score: " << score << "/10\n";
    fileSave.close();
    delete[] arr;
    delete[] ans;
    delete[] name;
}
void compQuiz()
{
    cout<<"MCQs for Pak study are: "<<endl;
    int score = 0;
    char *arr = new char[10];
    char *ans = new char[10];
    fstream fileObj("answersComp.txt", ios::in);
    for(int i = 0; i < 10; i++)
        fileObj>>ans[i];
    fileObj.close();
    cout << "Q1. What is the binary representation of the decimal number 10?\n";
    cout << "a) 1010\nb) 1001\nc) 1110\n";
    cout << "Your answer: ";
    cin >> arr[0];
    if (arr[0] == ans[0]) 
        score++;
    cout << "Q2. What is the basic building block of a digital circuit?\n";
    cout << "a) Transistor\nb) Capacitor\nc) Resistor\n";
    cout << "Your answer: ";
    cin >> arr[1];
    if (arr[1] == ans[1])
        score++;
    cout << "Q3. What does CPU stand for?\n";
    cout << "a) Central Processing Unit\nb) Computer Personal Unit\nc) Central Personal Unit\n";
    cout << "Your answer: ";
    cin >> arr[2];
    if (arr[2] == ans[2])
        score++;
    cout << "Q4. What is the highest level of programming language?\n";
    cout << "a) Assembly language\nb) High-level language\nc) Machine language\n";
    cout << "Your answer: ";
    cin >> arr[3];
    if (arr[3] == ans[3])
        score++;
    cout << "Q5. Which data structure follows the Last-In-First-Out (LIFO) principle?\n";
    cout << "a) Queue\nb) Stack\nc) Linked List\n";
    cout << "Your answer: ";
    cin >> arr[4];
    if (arr[4] == ans[4]) 
        score++;
    cout << "Q6. What does HTML stand for?\n";
    cout << "a) HyperText Markup Language\nb) Hyperlinks and Text Markup Language\nc) Home Tool Markup Language\n";
    cout << "Your answer: ";
    cin >> arr[5];
    if (arr[5] == ans[5]) 
        score++;
    cout << "Q7. Which programming language is known as the 'mother of all languages'?\n";
    cout << "a) C\nb) Python\nc) Assembly Language\n";
    cout << "Your answer: ";
    cin >> arr[6];
    if (arr[6] == ans[6]) 
        score++;
    cout << "Q8. What is the process of converting source code into machine code called?\n";
    cout << "a) Compilation\nb) Interpretation\nc) Execution\n";
    cout << "Your answer: ";
    cin >> arr[7];
    if (arr[7] == ans[7])
        score++;
    cout << "Q9. Which sorting algorithm has the worst-case time complexity of O(n^2)?\n";
    cout << "a) Quick Sort\nb) Merge Sort\nc) Bubble Sort\n";
    cout << "Your answer: ";
    cin >> arr[8];
    if (arr[8] == ans[8]) 
        score++;
    cout << "Q10. What is the purpose of an operating system?\n";
    cout << "a) To manage hardware resources\nb) To write code\nc) To design algorithms\n";
    cout << "Your answer: ";
    cin >> arr[9];
    if (arr[9] == ans[9])
        score++;
    fstream fileSave("recordsComp.txt", ios::app);
    cout<<"Enter your name without spaces (use - instead): ";
    char *name = new char[30];
    cin>>name;
    cout << name << " Your score: " << score << "/10\n";
    fileSave << name << " Your score: " << score << "/10\n";
    fileSave.close();
    delete[] arr;
    delete[] ans;
    delete[] name;
}