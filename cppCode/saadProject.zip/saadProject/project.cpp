#include<iostream>
#include<fstream>

using namespace std;
void sumMat();
void subMat();
void mulMat();
void tMat();

int main()
{
    cout<<"Welcome to matrix manipulation system!"
    <<"Enter 1 for matrix addition"<<endl
    <<"Enter 2 for matrix subtraction"<<endl
    <<"Enter 3 for matrix multiplication"<<endl
    <<"Enter 4 for matrix Transpose: ";
    int ch;
    cin>>ch;
    if(ch == 1)
        sumMat();
    else if(ch == 2)
        subMat();
    else if(ch == 3)
        mulMat();
    else if(ch == 4)
        tMat();
    else
        cout<<"Invalid option!";
    return 0;
}
void sumMat()
{
    cout<<"Enter rows and cols for matrices to be added: ";
    int rows, cols;
    cin>>rows>>cols;
    int **arr1 = new int*[rows];
    for(int i = 0; i < rows; i++)
        arr1[i] = new int[cols];
    cout<<"Enter values for array 1: "<<endl;
    for(int i = 0; i < rows; i++)
        for(int j = 0; j < cols; j++)
        {
            cout<<"Enter value for matrix1 index "<<i<<j<<": ";
            cin>>arr1[i][j];
        }
    int **arr2 = new int*[rows];
    for(int i = 0; i < rows; i++)
        arr2[i] = new int[cols];
    cout<<"Enter values for array 2: "<<endl;
    for(int i = 0; i < rows; i++)
        for(int j = 0; j < cols; j++)
        {
            cout<<"Enter value for matrix index "<<i<<j<<": ";
            cin>>arr2[i][j];
        }
    int **sumArr = new int*[rows];
    for(int i = 0; i < rows; i++)
        sumArr[i] = new int[cols];
    for(int i = 0; i < rows; i++)
        for(int j = 0; j < cols; j++)
            sumArr[i][j] = arr1[i][j] + arr2[i][j];
    fstream fileObj("sumFile.txt", ios::app);
    cout<<"Original Arrays are: "<<endl;
    fileObj<<"Original Arrays are: "<<endl;
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cout<<arr1[i][j]<<" ";
            fileObj<<arr1[i][j]<<" ";
        }
        cout<<endl;
        fileObj<<endl;
    }
    cout<<endl;
    fileObj<<endl;
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cout<<arr2[i][j]<<" ";
            fileObj<<arr2[i][j]<<" ";
        }
        cout<<endl;
        fileObj<<endl;
    }
    cout<<"Resulting array is: "<<endl;
    fileObj<<"Resulting array is: "<<endl;
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cout<<sumArr[i][j]<<" ";
            fileObj<<sumArr[i][j]<<" ";
        }
        cout<<endl;
        fileObj<<endl;
    }
    fileObj.close();
    for(int i = 0; i < rows; i++)
        delete[] arr1[i];
    delete[] arr1;
    for(int i = 0; i < rows; i++)
        delete[] arr2[i];
    delete[] arr2;
    for(int i = 0; i < rows; i++)
        delete[] sumArr[i];
    delete[] sumArr;
    
}
void subMat()
{
cout<<"Enter rows and cols for matrices to be subtracted: ";
    int rows, cols;
    cin>>rows>>cols;
    int **arr1 = new int*[rows];
    for(int i = 0; i < rows; i++)
        arr1[i] = new int[cols];
    cout<<"Enter values for array 1: "<<endl;
    for(int i = 0; i < rows; i++)
        for(int j = 0; j < cols; j++)
        {
            cout<<"Enter value for matrix1 index "<<i<<j<<": ";
            cin>>arr1[i][j];
        }
    int **arr2 = new int*[rows];
    for(int i = 0; i < rows; i++)
        arr2[i] = new int[cols];
    cout<<"Enter values for array 2: "<<endl;
    for(int i = 0; i < rows; i++)
        for(int j = 0; j < cols; j++)
        {
            cout<<"Enter value for matrix index "<<i<<j<<": ";
            cin>>arr2[i][j];
        }
    int **sumArr = new int*[rows];
    for(int i = 0; i < rows; i++)
        sumArr[i] = new int[cols];
    for(int i = 0; i < rows; i++)
        for(int j = 0; j < cols; j++)
            sumArr[i][j] = arr1[i][j] - arr2[i][j];
    fstream fileObj("subFile.txt", ios::app);
    cout<<"Original Arrays are: "<<endl;
    fileObj<<"Original Arrays are: "<<endl;
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cout<<arr1[i][j]<<" ";
            fileObj<<arr1[i][j]<<" ";
        }
        cout<<endl;
        fileObj<<endl;
    }
    cout<<endl;
    fileObj<<endl;
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cout<<arr2[i][j]<<" ";
            fileObj<<arr2[i][j]<<" ";
        }
        cout<<endl;
        fileObj<<endl;
    }
    cout<<"Resulting array is: "<<endl;
    fileObj<<"Resulting array is: "<<endl;
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cout<<sumArr[i][j]<<" ";
            fileObj<<sumArr[i][j]<<" ";
        }
        cout<<endl;
        fileObj<<endl;
    }
    fileObj.close();
    for(int i = 0; i < rows; i++)
        delete[] arr1[i];
    delete[] arr1;
    for(int i = 0; i < rows; i++)
        delete[] arr2[i];
    delete[] arr2;
    for(int i = 0; i < rows; i++)
        delete[] sumArr[i];
    delete[] sumArr;

}
void mulMat()
{
    cout<<"Enter rows and columns for matrix1: ";
    int rows1, cols1;
    cin>>rows1>>cols1;
    cout<<"Enter rows and columns for matrix2: ";
    int rows2, cols2;
    cin>>rows2>>cols2;
    if(cols1 != rows2)
        cout<<"Row and column conflict!";
    else
    {
        int **arr1 = new int*[rows1];
        int **arr2 = new int*[rows2];
        int mRows = rows1, mCols = cols2;
        int **finArr = new int*[mRows];
        for(int i = 0; i < rows1; i++)
            arr1[i] = new int[cols1];
        for(int i = 0; i < rows2; i++)
            arr2[i] = new int[cols2];
        for(int i = 0; i < mRows; i++)
            finArr[i] = new int[mCols];
        cout<<"Enter values for array1: "<<endl;
        for(int i = 0; i < rows1; i++)
            for(int j = 0; j < cols1; j++)
            {
                cout<<"Enter value for array index "<<i<<j<<": ";
                cin>>arr1[i][j];
            }
        cout<<"Enter values for array2: "<<endl;
        for(int i = 0; i < rows2; i++)
            for(int j = 0; j < cols2; j++)
            {
                cout<<"Enter value for array index "<<i<<j<<": ";
                cin>>arr2[i][j];
            }
        for (int i = 0; i < rows1; i++) 
            for (int j = 0; j < cols2; j++) 
            {
                finArr[i][j] = 0;
                for (int k = 0; k < cols1; k++) 
                    finArr[i][j] += arr1[i][k] * arr2[k][j];   
            } 
        fstream fileObj("mulFile.txt", ios::app);
        cout<<"Original arrays are: "<<endl;
        fileObj<<"Original arrays are: "<<endl;
        for(int i = 0; i < rows1; i++)
        {
            for(int j = 0; j < cols1; j++)
            {
                cout<<arr1[i][j]<<' ';
                fileObj<<arr1[i][j]<<' ';
            }
            cout<<endl;
            fileObj<<endl;
        }
        cout<<endl;
        fileObj<<endl;
        for(int i = 0; i < rows2; i++)
        {
            for(int j = 0; j < cols2; j++)
            {
                cout<<arr2[i][j]<<' ';
                fileObj<<arr2[i][j]<<' ';
            }
            cout<<endl;
            fileObj<<endl;
        }
        cout<<"Resulting array is: "<<endl;
        fileObj<<"Resulting array is: "<<endl;
        for(int i = 0; i < mRows; i++)
        {
            for(int j = 0; j < mCols; j++)
            {
                cout<<finArr[i][j]<<' ';
                fileObj<<finArr[i][j]<<' ';
            }
            cout<<endl;
            fileObj<<endl;
        }
        for(int i = 0; i < rows1; i++)
            delete[] arr1[i];
        delete[] arr1;
        for(int i = 0; i < rows2; i++)
            delete[] arr2[i];
        delete[] arr2;
        for(int i = 0; i < mRows; i++)
            delete[] finArr[i];
        delete[] finArr;
        fileObj.close();
    }
}
void tMat()
{
    int rows, cols;
    cout<<"Enter the value for rows and cols for matrix: ";
    cin>>rows>>cols;
    int **arr = new int*[rows];
    for(int i = 0; i < rows; i++)
        arr[i] = new int[cols];
    int tRows = cols, tCols = rows;
    int **tArr = new int*[rows];
    for(int i = 0; i < tRows; i++)
        tArr[i] = new int[tCols];
    fstream fileObj("tranFile.txt", ios::app);
    cout<<"Enter values for Matrix: "<<endl;
    for(int i = 0; i < rows; i++)
        for(int j = 0; j < cols; j++)
        {
            cout<<"Enter value for index "<<i<<j<<": ";
            cin>>arr[i][j];
        }
    for(int i = 0; i < rows; i++)
        for(int j = 0; j < cols; j++)
            tArr[j][i] = arr[i][j];
    cout<<"Original Matrix is: "<<endl;
    fileObj<<"Original Matrix is: "<<endl;
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cout<<arr[i][j]<<" ";
            fileObj<<arr[i][j]<<" ";
        }
        cout<<endl;
        fileObj<<endl;
    }
    cout<<"Transpose matrix is: "<<endl;
    fileObj<<"Transpose matrix is: "<<endl;
    for(int i = 0; i < tRows; i++)
    {
        for(int j = 0; j < tCols; j++)
        {
            cout<<tArr[i][j]<<' ';
            fileObj<<tArr[i][j]<<' ';
        }
        cout<<endl;
        fileObj<<endl;
    }
    fileObj.close();
    for(int i = 0; i < rows; i++)
        delete[] arr[i];
    delete[] arr;
    for(int i = 0; i < tRows; i++)
        delete[] tArr[i];
    delete[] tArr;
}